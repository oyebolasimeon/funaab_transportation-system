<?php
require_once "header.php";
?>
		<!-- hero area start -->
		<section class="hero-area" id="home">
			<div class="hero-area-slider">
				<div class="hero-area-single-slide">
					<div class="container">
						<div class="row">
							<div class="col-lg-7">
								<div class="hero-area-content">
									<h1 style="color: green;">FUNAAB TRANSPORT MANAGEMENT SYSTEM</h1>
									<p style="color: green;">Book Your Trip With Ease</p>
								
								</div>
							</div>
							<div class="col-lg-5">
								<div class="hand-mockup text-lg-left text-center">
									<img src="assets/img/funaab2.jpg" alt="Hand Mockup" />
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="hero-area-single-slide">
					<div class="container">
						<div class="row">
							<div class="col-lg-7">
								<div class="hero-area-content">
									<h1 style="color: green;">FUNAAB BUREAU OF TRANSPORTATION (FUNAABOT)</h1>
									<p style="color: green;">Anywhere With Just N20 Only</p>
								
								</div>
							</div>
							<div class="col-lg-5">
								<div class="hand-mockup text-lg-left text-center">
									<img src="assets/img/funaab3.jpg" alt="Hand Mockup" />
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="hero-area-single-slide">
					<div class="container">
						<div class="row">
							<div class="col-lg-7">
								<div class="hero-area-content">
									<h1 style="color: green;">Traffic Management System</h1>
									<p style="color: green;">Developed by Group 1 ... Supervised by Dr. (Mrs) Ojo </p>
									<a href="#" class="appao-btn">Google Play</a>
									<a href="#" class="appao-btn">App Store</a>
								</div>
							</div>
							<div class="col-lg-5">
								<div class="hand-mockup text-lg-left text-center">
									<img src="assets/img/funaab4.jpg" alt="Hand Mockup" />
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section><!-- hero area end -->
		<!-- about section start -->
		<section class="about-area ptb-90">
			<div class="container">
				<div class="row">
					<div class="col-lg-12">
					    <div class="sec-title">
							<h2>FUNAABOT APP<span class="sec-title-border"><span></span><span></span><span></span></span></h2>
							<p>Developed by Group 1</p>

						</div>
					</div>
				</div>
				<div class="row" >
					<div class="col-lg-12" id="lsdone" >
					    <div class="single-about-box">
							<i class="icofont icofont-school-bus"></i>
							<h4>Book A Trip</h4><hr><hr>
							
							<div class="row">
								<div class="col-lg-6" >
									<div class="contact-form" >
										<p>MANCOT ON YOUR FINGER TIPS</p>
							<p class="form-message">Note You are to pay a fee of N20</p>
							<form id="contact-form" action="request-ride.php" method="POST">
				                <input type="text" name="name" placeholder="Enter Your Name" required>
				                <input type="text" name="matric" placeholder="Enter Matric/SP Number" required>
				                <input type="email" name="email" placeholder="Enter Your Email" required>
				                <input type="text" name="phone" placeholder="Enter Your Phone Number" required>
				                <input type="text" name="destination" placeholder="Enter Destination" required>
				                <button type="submit" name="submit">Book A Seat</button>
				                <hr><hr>
				            </form>
						</div>
								</div>
								<div class="col-lg-6" >
									<div class="contact-form" >
							<p class="form-message"></p>
							<img src="assets/img/mancot.jpg">
						</div>
								</div>
							</div>

							
							
						<!--	<button type="submit" style="height: 60px; width: 60px; border-radius: 20px; padding-left: 10px; background-color: green;"><i class="fa fa-hand-o-right"></i></button><br>
							<button type="submit" style="height: 60px; width: 60px; border-radius: 20px; padding-left: 10px; background-color: green;"><i class="fa fa-hand-o-right"></i></button><br>// echo '<button type="submit" style="height: 60px; width: 60px; border-radius: 20px; padding-left: 10px; background-color:'.$result['color'].';"><i class="fa fa-hand-o-right"></i></button><br>';

			
						-->
						</div>
					</div>
					
				
				</div>

				
			</div>
		</section><!-- about section end -->

		
		<!-- feature section start -->
		<!-- feature section end -->
		<!-- showcase section start -->
		<!-- showcase section end -->
		<!-- video section start -->
		<!-- blog section end -->
		<!-- google map area start -->
		<div class="google-map"></div>
		<!-- google map area end -->
		<!-- footer section start -->
		<footer class="footer" id="contact">
			<div class="container">
				<div class="row">
                   
                    
				</div>
				<div class="row">
                    <div class="col-lg-12">
						<div class="subscribe-form">
							<form action="#">
								<input type="text" placeholder="Your email address here">
								<button type="submit">Subcribe</button>
							</form>
						</div>
                    </div>
				</div>
				<div class="row">
                    <div class="col-lg-12">
						<div class="copyright-area">
							<ul>
								<li><a href="#"><i class="icofont icofont-social-facebook"></i></a></li>
								<li><a href="#"><i class="icofont icofont-social-twitter"></i></a></li>
								<li><a href="#"><i class="icofont icofont-brand-linkedin"></i></a></li>
								<li><a href="#"><i class="icofont icofont-social-pinterest"></i></a></li>
								<li><a href="#"><i class="icofont icofont-social-google-plus"></i></a></li>
							</ul>
							<p>&copy; <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved </i> by <a href="#" target="_blank">Group One - CSC 447</a>
<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --></p>
						</div>
                    </div>
				</div>
			</div>
		</footer><!-- footer section end -->
		<a href="#" class="scrollToTop">
			<i class="icofont icofont-arrow-up"></i>
		</a>
		<div class="switcher-area" id="switch-style">
			<div class="display-table">
				<div class="display-tablecell">
					<a class="switch-button" id="toggle-switcher"><i class="icofont icofont-question-circle"></i></a>
					<div class="switched-options">
						<div class="config-title">QUICK RESPONSE:</div>
						<ul>
							<li><a href="https://">Live Chat Suppory <i class="fa fa-headphones"></i></a></li>
							<li class="active"><a href="travel-history.php">Bus Travel History <i class="fa fa-history"></i> <i class="fa fa-bus"></i></a></li>
						</ul>
						
					</div>
				</div>
			</div>
		</div>
		<!-- jquery main JS -->
		<script src="assets/js/jquery.min.js"></script>
		<!-- Bootstrap JS -->
		<script src="assets/js/bootstrap.min.js"></script>
		<!-- Slick nav JS -->
		<script src="assets/js/jquery.slicknav.min.js"></script>
		<!-- Slick JS -->
		<script src="assets/js/slick.min.js"></script>
		<!-- owl carousel JS -->
		<script src="assets/js/owl.carousel.min.js"></script>
		<!-- Popup JS -->
		<script src="assets/js/jquery.magnific-popup.min.js"></script>
		<!-- Counter JS -->
		<script src="assets/js/jquery.counterup.min.js"></script>
		<!-- Counterup waypoints JS -->
		<script src="assets/js/waypoints.min.js"></script>
	    <!-- YTPlayer JS -->
	    <script src="assets/js/jquery.mb.YTPlayer.min.js"></script>
		<!-- jQuery Easing JS -->
		<script src="assets/js/jquery.easing.1.3.js"></script>
		<!-- Gmap JS -->
		<script src="assets/js/gmap3.min.js"></script>
        <!-- Google map api -->
        <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBnKyOpsNq-vWYtrwayN3BkF3b4k3O9A_A"></script>
		<!-- Custom map JS -->
		<script src="assets/js/custom-map.js"></script>
		<!-- WOW JS -->
		<script src="assets/js/wow-1.3.0.min.js"></script>
		<!-- Switcher JS -->
		<script src="assets/js/switcher.js"></script>
		<!-- main JS -->
		<script src="assets/js/main.js"></script>
	</body>
</html>