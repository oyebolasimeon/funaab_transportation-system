<section class="hero-area" id="home">
			<div class="hero-area-slider">
				<div class="hero-area-single-slide">
					<div class="container">
						<div class="row">
							<div class="col-lg-7">
								<div class="hero-area-content">
									<h1 style="color: green;">FUNAAB TRANSPORT MANAGEMENT SYSTEM</h1>
									<p style="color: green;">Book Your Trip With Ease</p>
								
								</div>
							</div>
							<div class="col-lg-5">
								<div class="hand-mockup text-lg-left text-center">
									<img src="assets/img/funaab2.jpg" alt="Hand Mockup" />
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="hero-area-single-slide">
					<div class="container">
						<div class="row">
							<div class="col-lg-7">
								<div class="hero-area-content">
									<h1 style="color: green;">FUNAAB BUREAU OF TRANSPORTATION (FUNAABOT)</h1>
									<p style="color: green;">Anywhere With Just N20 Only</p>
								
								</div>
							</div>
							<div class="col-lg-5">
								<div class="hand-mockup text-lg-left text-center">
									<img src="assets/img/funaab3.jpg" alt="Hand Mockup" />
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="hero-area-single-slide">
					<div class="container">
						<div class="row">
							<div class="col-lg-7">
								<div class="hero-area-content">
									<h1 style="color: green;">Traffic Management System</h1>
									<p style="color: green;">Developed by Group 1 ... Supervised by Dr. (Mrs) Ojo </p>
									<a href="#" class="appao-btn">Google Play</a>
									<a href="#" class="appao-btn">App Store</a>
								</div>
							</div>
							<div class="col-lg-5">
								<div class="hand-mockup text-lg-left text-center">
									<img src="assets/img/funaab4.jpg" alt="Hand Mockup" />
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>