<?php

    //PHP code section to connect with the database
    
    $servername = "localhost"; //database server address Host Name
    $username = "root"; //databse server username
    $password = ""; ///database server password
    $dbname = "transport"; //database name

    $conn = mysqli_connect($servername,$username,$password,$dbname); //MySQL connection Query

    
    if(!$conn){
        die("Sorry i cannot access database currently".mysqli_connect_error());
    }

    if (!mysqli_select_db($conn,'transport')) {
        echo "database not selected";
    }





  ?>