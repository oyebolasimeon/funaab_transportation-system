<?php require_once "header.php";
require_once "banner.php";
?>

<section class="about-area ptb-90">
			<div class="container">
				<div class="row">
					<div class="col-lg-12">
					    <div class="sec-title">
							<h2>FUNAABOT APP<span class="sec-title-border"><span></span><span></span><span></span></span></h2>
							<p>Developed by Group 1</p>

						</div>
					</div>
				</div>
				<div class="row" >
					<div class="col-lg-12" id="lsdone" >
					    <div class="single-about-box">
							<i class="icofont icofont-school-bus"></i>
							<h4>Travel History</h4><hr><hr>
							
							<div class="row">
								<div class="col-lg-12" >
									
								<div class="col-lg-12" >
									<div class="contact-form" >
							<p class="form-message"></p>

							  <?php

                                include("connection.php");
                                {
$sql=mysqli_query($conn,"select * from ticket");
                               echo '<table id="bootstrap-data-table-export" class="table table-striped table-bordered">';
                                   echo  '<thead>
                                        <tr>
                                            <th>S/N</th>
                                            <th>Ticket Number</th>
                                            <th>Name</th>
                                            <th>Matric Number</th>
                                            <th>Date</th>
                                        </tr>
                                    </thead>';
                                      echo '<tbody>';

                                while($result=mysqli_fetch_assoc($sql))
                                    {
$id=$result['id'];
                                  
                                        echo '<tr>';
                                         echo "<td>".$result['id']. "</td>"; 
                                         echo "<td>".$result['ticket_number']. "</td>";
                                         echo "<td>".$result['name']. "</td>";
                                         echo "<td>".$result['matric']. "</td>";
                                         echo "<td>".$result['dates']. "</td>";
                                         
                                        echo "</tr>";
                                        }
                                    echo "</tbody>";
                               echo "</table>"; 
}
                                ?>
						</div>
								</div>
							</div>

							
				
						</div>
					</div>
					
				
				</div>

				
			</div>
		</section>
		<?php
		require_once "footer.php";?>