-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 06, 2021 at 04:43 PM
-- Server version: 10.4.13-MariaDB
-- PHP Version: 7.2.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `traffic`
--

-- --------------------------------------------------------

--
-- Table structure for table `lightone`
--

CREATE TABLE `lightone` (
  `id` int(11) NOT NULL,
  `color` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `lightone`
--

INSERT INTO `lightone` (`id`, `color`) VALUES
(1, 'red'),
(2, 'yellow'),
(3, 'green'),
(4, 'red');

-- --------------------------------------------------------

--
-- Table structure for table `lightthree`
--

CREATE TABLE `lightthree` (
  `id` int(11) NOT NULL,
  `color` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `lightthree`
--

INSERT INTO `lightthree` (`id`, `color`) VALUES
(1, 'red'),
(2, 'yellow'),
(3, 'green');

-- --------------------------------------------------------

--
-- Table structure for table `lighttwo`
--

CREATE TABLE `lighttwo` (
  `id` int(11) NOT NULL,
  `color` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `lighttwo`
--

INSERT INTO `lighttwo` (`id`, `color`) VALUES
(1, 'red'),
(2, 'green'),
(3, 'red');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `lightone`
--
ALTER TABLE `lightone`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lightthree`
--
ALTER TABLE `lightthree`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lighttwo`
--
ALTER TABLE `lighttwo`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `lightone`
--
ALTER TABLE `lightone`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `lightthree`
--
ALTER TABLE `lightthree`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `lighttwo`
--
ALTER TABLE `lighttwo`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
