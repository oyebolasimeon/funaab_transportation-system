<?php 

include("connection.php"); //section used to call the PHP Database connection module

$name = $_POST['name'];
$matric = $_POST['matric'];
$email = $_POST['email'];
$phone = $_POST['phone']; 
$destination = $_POST['destination'];
$ticket_generation_id = uniqid('', true);
$date =  (date("h:i:sa"));//PHP code to post color string to the database

 $result = "INSERT INTO ticket(name, matric, email, phone, destination, ticket_number, dates) VALUES ('$name','$matric','$email','$phone','$destination','$ticket_generation_id','$date')"; //MySQL query code section

    if (mysqli_query($conn,$result)) { //PHP and MySQL section to validate if the connection is valid 
    	

    		echo '<script>alert("Seat Booked")</script>';
require_once "header.php";
require_once "banner.php";
echo '<section class="about-area ptb-90">
			<div class="container">
				<div class="row">
					<div class="col-lg-12">
					    <div class="sec-title">
							<h2>FUNAABOT APP<span class="sec-title-border"><span></span><span></span><span></span></span></h2>
							<p>Developed by Group 1</p>

						</div>
					</div>
				</div>
				<div class="row" >
					<div class="col-lg-12" id="lsdone" >
					    <div class="single-about-box">
							<i class="icofont icofont-school-bus"></i>
							<h4>Transportation E-Ticket</h4><hr><hr>
							
							<div class="row">
								<div class="col-lg-12" >
									
								<div class="col-lg-12" >
									<div class="contact-form" >
							<p class="form-message">Screenshot This page and present at the Park<hr></p>';
							echo '<p>Name: <b>'.$name.'</b> </p><br>';
							echo '<p>Matric Number: <b>'.$matric.'</b> </p><br>';
							echo '<p>Destination: <b>'.$destination.'</b> </p><br>';
							echo '<p>Ticket No: <b>'.$ticket_generation_id.'</b> </p><br>';
							echo '<p>Time Ticket was Allocated: <b>'.$date.'</b> </p><br>';
							echo '<button style="background-color: black; color: #ffffff" onclick="window.print()">Print Ticket</button>';
						echo'</div>
								</div>
							</div>

							
				
						</div>
					</div>
					
				
				</div>

				
			</div>
		</section>';
		require_once "footer.php";
    	 //PHP and JavaScript Code to redirect to the index page(Main Page)

    }
    else{
    			echo '<script>alert("color changing error")</script>'; // PHP and JavaScript code section to display an alert box if the connection failed
    }	



 ?>